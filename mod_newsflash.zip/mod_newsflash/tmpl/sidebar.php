<?php defined('_JEXEC') or die; ?>

<div class="newsflash-sidebar">
  <?php foreach ($items as $item): ?>
    <div class="news-item">
      <?php if ($item['image']): ?>
        <img src="<?= $item['image'] ?>" alt="<?= htmlspecialchars($item['title']) ?>" />
      <?php endif; ?>
      <div class="info">
        <a href="<?= $item['link'] ?>" target="_blank"><?= htmlspecialchars($item['title']) ?></a>
        <small><?= $item['pubDate'] ?></small>
      </div>
    </div>
  <?php endforeach; ?>
</div>

<style>
.newsflash-sidebar {
  display: flex;
  flex-direction: column;
  gap: 10px;
}
.news-item {
  display: flex;
  gap: 10px;
  align-items: flex-start;
}
.news-item img {
  width: 60px;
  height: 60px;
  object-fit: cover;
  border-radius: 6px;
}
.news-item .info {
  flex: 1;
}
.news-item a {
  font-size: 14px;
  font-weight: bold;
  color: #222;
  text-decoration: none;
}
.news-item a:hover {
  color: #007bff;
}
.news-item small {
  font-size: 11px;
  color: #888;
}
</style>
