/*
 * Tên phần mềm: MODULE TIN TỨC FOR JOOMLA
 * Copyright (C) 2025 [HOAIDUY]
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 *//*
 * Tên phần mềm: MODULE TIN TỨC FOR JOOMLA
 * Copyright (C) 2025 [HOAIDUY]
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */
<?php defined('_JEXEC') or die; ?>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css" />
<script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>

<div class="swiper newsflash-swiper">
  <div class="swiper-wrapper">
    <?php foreach ($items as $item): ?>
      <div class="swiper-slide">
        <div class="news-card">
          <?php if ($item['image']): ?>
            <div class="news-img" style="background-image: url('<?= $item['image'] ?>');"></div>
          <?php endif; ?>
          <div class="news-content">
            <h4><a href="<?= $item['link'] ?>" target="_blank"><?= htmlspecialchars($item['title']) ?></a></h4>
            <small><?= $item['pubDate'] ?></small>
            <p><?= mb_substr($item['description'], 0, 100) ?>…</p>
          </div>
        </div>
      </div>
    <?php endforeach; ?>
  </div>
  <div class="swiper-button-next"></div>
  <div class="swiper-button-prev"></div>
  <div class="swiper-pagination"></div>
</div>

<style>
.newsflash-swiper {
  padding: 20px 0;
}
.news-card {
  background: #fff;
  border-radius: 12px;
  box-shadow: 0 2px 8px rgba(0,0,0,0.1);
  overflow: hidden;
}
.news-img {
  height: 150px;
  background-size: cover;
  background-position: center;
}
.news-content {
  padding: 15px;
}
.news-content h4 {
  font-size: 16px;
  margin: 0 0 5px;
}
.news-content p {
  font-size: 14px;
  color: #555;
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function () {
  new Swiper('.newsflash-swiper', {
  slidesPerView: 1,
  spaceBetween: 20,
  loop: true,
  autoplay: {
    delay: 2000,       // chuyển slide mỗi 4 giây
    disableOnInteraction: false
  },
  navigation: {
    nextEl: '.swiper-button-next',
    prevEl: '.swiper-button-prev'
  },
  pagination: {
    el: '.swiper-pagination',
    clickable: true
  },
  breakpoints: {
    600: { slidesPerView: 2 },
    900: { slidesPerView: 3 }
  }
});

});


</script>
