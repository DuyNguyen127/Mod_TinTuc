
<?php
defined('_JEXEC') or die;

class ModNewsflashHelper
{
    public static function getItems($params)
    {
        $url = $params->get('feed_url');
        $limit = (int) $params->get('count', 5);
        $items = [];

        if (empty($url)) return [];

        try {
            $rss = simplexml_load_file($url, 'SimpleXMLElement', LIBXML_NOCDATA);
            if (!$rss || !isset($rss->channel->item)) return [];

            foreach ($rss->channel->item as $item) {
                $desc = (string) $item->description;
                preg_match('/<img[^>]+src=\"([^\"]+)\"/i', $desc, $matches);
                $image = $matches[1] ?? '';

                $items[] = [
                    'title' => (string) $item->title,
                    'link' => (string) $item->link,
                    'description' => strip_tags($desc),
                    'image' => $image,
                    'pubDate' => date('d/m/Y', strtotime((string) $item->pubDate))
                ];
            }
        } catch (Exception $e) {
            return [];
        }

        return array_slice($items, 0, $limit);
    }
}
