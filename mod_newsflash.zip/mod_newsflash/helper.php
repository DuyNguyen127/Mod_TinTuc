/*
 * Tên phần mềm: MODULE TIN TỨC FOR JOOMLA
 * Copyright (C) 2025 [HOAIDUY]
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 *//*
 * Tên phần mềm: MODULE TIN TỨC FOR JOOMLA
 * Copyright (C) 2025 [HOAIDUY]
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */
<?php
defined('_JEXEC') or die;

class ModNewsflashHelper
{
    public static function getItems($params)
    {
        $url = $params->get('feed_url');
        $limit = (int) $params->get('count', 5);
        $items = [];

        if (empty($url)) return [];

        try {
            $rss = simplexml_load_file($url, 'SimpleXMLElement', LIBXML_NOCDATA);
            if (!$rss || !isset($rss->channel->item)) return [];

            foreach ($rss->channel->item as $item) {
                $desc = (string) $item->description;
                preg_match('/<img[^>]+src=\"([^\"]+)\"/i', $desc, $matches);
                $image = $matches[1] ?? '';

                $items[] = [
                    'title' => (string) $item->title,
                    'link' => (string) $item->link,
                    'description' => strip_tags($desc),
                    'image' => $image,
                    'pubDate' => date('d/m/Y', strtotime((string) $item->pubDate))
                ];
            }
        } catch (Exception $e) {
            return [];
        }

        return array_slice($items, 0, $limit);
    }
}
