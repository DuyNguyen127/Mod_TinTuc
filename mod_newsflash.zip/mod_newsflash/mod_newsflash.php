/*
 * Tên phần mềm: MODULE TIN TỨC FOR JOOMLA
 * Copyright (C) 2025 [HOAIDUY]
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 *//*
 * Tên phần mềm: MODULE TIN TỨC FOR JOOMLA
 * Copyright (C) 2025 [HOAIDUY]
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */
<?php
// File: mod_newsflash.php

defined('_JEXEC') or die;

require_once __DIR__ . '/helper.php';

$items = ModNewsflashHelper::getItems($params);
$position = $module->position;
$layout = in_array($position, ['position-7', 'position-9', 'sidebar']) ? 'sidebar' : 'default';

require JModuleHelper::getLayoutPath('mod_newsflash', $layout);