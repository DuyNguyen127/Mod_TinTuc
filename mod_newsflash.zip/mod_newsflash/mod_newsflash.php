<?php
// File: mod_newsflash.php

defined('_JEXEC') or die;

require_once __DIR__ . '/helper.php';

$items = ModNewsflashHelper::getItems($params);
$position = $module->position;
$layout = in_array($position, ['position-7', 'position-9', 'sidebar']) ? 'sidebar' : 'default';

require JModuleHelper::getLayoutPath('mod_newsflash', $layout);